from pathlib import Path

from distutils.core import setup
import copy

dir_parent = Path(__file__).parent

def read_requirements():
    with open(str(dir_parent / "requirements.txt"), "r") as req:
        content = req.read()  ## read the file
        requirements = content.split("\n") ## make a list of requirements split by (\n) which is the new line character

    ## Filter out any empty strings from the list
    requirements = [req for req in requirements if req]
    ## Filter out any lines starting with #
    requirements = [req for req in requirements if not req.startswith("#")]
    ## Remove any commas, quotation marks, and spaces from each requirement
    requirements = [req.replace(",", "").replace("\"", "").replace("\'", "").strip() for req in requirements]

    return requirements

deps_all = read_requirements()

## Dependencies: latest versions of requirements
### remove everything starting and after the first =,>,<,! sign
deps_names = [req.split('=')[0].split('>')[0].split('<')[0].split('!')[0] for req in deps_all]
deps_all_dict = dict(zip(deps_names, deps_all))

deps_all_latest = copy.deepcopy(deps_names)

## Make different versions of dependencies
### Also pull out the version number from the requirements (specified in deps_all_dict values).
deps_core = [deps_all_dict[dep] for dep in [
    'Pillow',
    'numpy',
    'onnxruntime',
    'opencv-python',
]]

deps_extras = [deps_all_dict[dep] for dep in [
]] + deps_core


# print({
#     'deps_all': deps_all,
#     'deps_all_latest': deps_all_latest,
#     'deps_core': deps_core,
#     'deps_extras': deps_extras,
# })

## Get version number
with open(str(dir_parent / "rune_ocr" / "__init__.py"), "r") as f:
    for line in f:
        if line.startswith("__version__"):
            version = line.split("=")[1].strip().replace("\"", "").replace("\'", "")
            break

setup(
    name='rune_ocr',
    version=version,
    author='Richard Hakim',
    keywords=['runes', 'ocr'],
    license='LICENSE',
    description='A tool for optical character recognition (OCR) of runic characters using YOLO.',
    long_description_content_type="text/markdown",
    url='https://github.com/RichieHakim/rune_ocr',

    packages=[
        'rune_ocr',
        'rune_ocr.training',
    ],
    
    install_requires=[],
    extras_require={
        'all': deps_all,
        'all_latest': deps_all_latest,
        'core': deps_core,
        'extras': deps_extras,
    },
)