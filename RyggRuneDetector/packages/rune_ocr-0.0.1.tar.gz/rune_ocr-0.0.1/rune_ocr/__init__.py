__all__ = [
    'training',
    'inference',
]

for pkg in __all__:
    exec('from . import ' + pkg)

__version__ = '0.0.1'