import torch
from torch import nn

def intersection_over_union(boxes_preds, boxes_labels, box_format="midpoint"):
    """
    Calculates intersection over union for each predicted bounding box to each
    correct bounding box within each grid cell.

    Parameters:
        boxes_preds (tensor): Predictions of Bounding Boxes (N, S, S, B, 4)
        boxes_labels (tensor): Correct labels of Bounding Boxes (N, S, S, B, 4)
        box_format (str): midpoint (x, y, w, h) or corners (x1, x2, y1, y2)
    Returns:
        tensor: Intersection over union for all examples
    """

    if box_format == "midpoint":
        box_pred_x1 = boxes_preds[..., 0] - boxes_preds[..., 2] / 2  ## shape: (N, S, S, B)
        box_pred_y1 = boxes_preds[..., 1] - boxes_preds[..., 3] / 2
        box_pred_x2 = boxes_preds[..., 0] + boxes_preds[..., 2] / 2
        box_pred_y2 = boxes_preds[..., 1] + boxes_preds[..., 3] / 2
        box_label_x1 = boxes_labels[..., 0] - boxes_labels[..., 2] / 2
        box_label_y1 = boxes_labels[..., 1] - boxes_labels[..., 3] / 2
        box_label_x2 = boxes_labels[..., 0] + boxes_labels[..., 2] / 2
        box_label_y2 = boxes_labels[..., 1] + boxes_labels[..., 3] / 2

    elif box_format == "corners":
        box_pred_x1, box_pred_y1, box_pred_x2, box_pred_y2 = boxes_preds[..., 0], boxes_preds[..., 1], boxes_preds[..., 2], boxes_preds[..., 3]
        box_label_x1, box_label_y1, box_label_x2, box_label_y2 = boxes_labels[..., 0], boxes_labels[..., 1], boxes_labels[..., 2], boxes_labels[..., 3]

    # Reshape predicted boxes to (N, S, S, B_pred, B_gt) and ground truth  boxes to
    # (N, S, S, B_pred, B_gt) to compare each predicted box to each ground truth box
    fn_reshape_pred  = lambda x : x.unsqueeze(-1).repeat(1, 1, 1, 1, boxes_labels.shape[-2])
    fn_reshape_label = lambda x : x.unsqueeze(-2).repeat(1, 1, 1, boxes_preds.shape[-2],  1)
    box_pred_x1, box_pred_y1, box_pred_x2, box_pred_y2     = map(fn_reshape_pred,  [box_pred_x1, box_pred_y1, box_pred_x2, box_pred_y2    ])  ## shape: (N, S, S, B_pred, B_gt)
    box_label_x1, box_label_y1, box_label_x2, box_label_y2 = map(fn_reshape_label, [box_label_x1, box_label_y1, box_label_x2, box_label_y2])  ## shape: (N, S, S, B_pred, B_gt)

    # Calculate the intersection x1, y1, x2, y2
    x1 = torch.max(box_pred_x1, box_label_x1)  ## shape: (N, S, S, B_pred, B_gt)
    y1 = torch.max(box_pred_y1, box_label_y1)
    x2 = torch.min(box_pred_x2, box_label_x2)
    y2 = torch.min(box_pred_y2, box_label_y2)

    # Calculate the area of intersection
    intersection = (x2 - x1).clamp(0) * (y2 - y1).clamp(0)  ## shape: (N, S, S, B_pred, B_gt)

    # Calculate the area of both boxes
    box_pred_area  = abs((box_pred_x2 - box_pred_x1) * (box_pred_y2 - box_pred_y1))  ## shape: (N, S, S, B_pred, B_gt)
    box_label_area = abs((box_label_x2 - box_label_x1) * (box_label_y2 - box_label_y1))

    # Calculate the union area by subtracting the intersection area from the
    # combined area of the two boxes
    union = box_pred_area + box_label_area - intersection  ## shape: (N, S, S, B_pred, B_gt)

    # Calculate the IoU
    iou = intersection / (union + 1e-6)  ## shape: (N, S, S, B_pred, B_gt)

    return iou




class Loss_YOLO(nn.Module):
    """
    The Loss_YOLO class calculates the loss for a YOLO (You Only Look Once)
    object detection model. It computes four types of losses: box coordinate
    loss, objectness loss, no-objectness loss, and class loss.
    RH 2023
    
    Attributes:
        S (int):
            The grid size. The input image is divided into an SxS grid.
        B (int):
            The number of bounding boxes each grid cell can predict. 
        C (int):
            The number of classes that the model can predict.
        mse (torch.nn.modules.loss.MSELoss):
            The Mean Squared Error loss function.
        bce (torch.nn.modules.loss.BCEWithLogitsLoss):
            The Binary Cross-Entropy with Logits loss function.
        ce (torch.nn.modules.loss.CrossEntropyLoss):
            The Cross-Entropy loss function.

    Args:
        S (int): 
            Grid size.
        B (int): 
            Number of bounding boxes each grid cell can predict.
        C (int): 
            Number of classes.
    """
    def __init__(
        self, 
        S: int = 7, 
        B: int = 2, 
        C: int = 20, 
        lambda_xy=0.1,
        lambda_wh=0.05,
        lambda_obj=0.05,
        lambda_fp=1.0,
        lambda_class=50.0,
    ):
        super(Loss_YOLO, self).__init__()
        self.mse = nn.MSELoss(reduction="sum")
        self.bce = nn.BCEWithLogitsLoss(reduction="sum")
        self.ce = nn.CrossEntropyLoss(reduction="sum")
        
        # Grid size
        self.S = S
        # Number of bounding boxes
        self.B = B
        # Number of classes
        self.C = C

        # These are from YOLO paper, signifying how much we penalize certain aspect of the loss
        self.lambda_xy = lambda_xy
        self.lambda_wh = lambda_wh
        self.lambda_obj = lambda_obj
        self.lambda_fp = lambda_fp
        self.lambda_class = lambda_class

    def forward(
        self, 
        predictions: torch.Tensor, 
        targets: torch.Tensor
    ) -> torch.Tensor:
        """
        Calculates the total YOLO loss.
        
        In both `predictions` and `target`, the last dimension is broken down
        into 5 + C elements. The first 5 elements of the last dimension are: \n
            - **x**: The x-coordinate of the center of the bounding box
            - **y**: The y-coordinate of the center of the bounding box
            - **w**: The width of the bounding box
            - **h**: The height of the bounding box
            - **conf** or **'objectness'**: The confidence score of whether the
              bounding box contains an object or not

        Args:
            predictions (torch.Tensor): 
                The predictions from the model. Shape: *(N, S, S, B, 5+C)*
            targets (torch.Tensor): 
                The ground truth labels. Shape: *(N, S, S, B, 5+C)*

        Returns:
            (torch.Tensor): 
                loss (torch.Tensor): 
                    The total YOLO loss.
        """
        N = predictions.shape[0]

        # Make useful variables
        exists_box = targets[..., 4] > 0.5  ## shape: (N, S, S, B)
        exists_box_expanded = exists_box[...,None].expand_as(targets)  ## shape: (N, S, S, B, 5+C). Last dim is just repeated B times.
        exists_box_expanded_not = ~ exists_box_expanded  ## shape: (N, S, S, B, 5+C).

        preds_exists       = predictions[exists_box_expanded].view(-1, 5 + self.C)  ## shape: ('n_exists', 5+C). 'n_exists' is the number of target bounding boxes (across [N, S, S, B]) that contain an object.
        # preds_exists_coords = preds_exists[:, 0:4] ## shape: ('n_exists', 4). The first 4 values are the x, y, w, h values.
        preds_exists_class = preds_exists[: 5:]  ## shape: ('n_exists', C). The last C values are the class probabilities.

        preds_exists_not       = predictions[exists_box_expanded_not].view(-1, 5 + self.C)  ## shape: ('n_not_exists', 5+C).
        # preds_exists_not_coords = preds_exists_not[:, 0:4]  ## shape: ('n_not_exists', 4).
        preds_exists_not_confidence   = preds_exists_not[..., 4]  ## shape: ('n_not_exists',).
        # preds_exists_not_class = preds_exists_not[: 5:]  ## shape: ('n_not_exists', C).

        targets_exists       = targets[exists_box_expanded].view(-1, 5 + self.C)  ## shape: ('n_exists', 5+C).
        # targets_exists_coords = targets_exists[:, 0:4]  ## shape: ('n_exists', 4).
        targets_exists_class = targets_exists[: 5:]  ## shape: ('n_exists', C).

        targets_exists_not       = targets[exists_box_expanded_not].view(-1, 5 + self.C)  ## shape: ('n_not_exists', 5+C).
        # targets_exists_not_coords = targets_exists_not[:, 0:4]  ## shape: ('n_not_exists', 4).
        targets_exists_not_confidence = targets_exists_not[..., 4]  ## shape: ('n_not_exists',).
        # targets_exists_not_class = targets_exists_not[: 5:]  ## shape: ('n_not_exists', C).


        # ========================= #
        #   LOSS: FALSE POSITIVES   #
        # ========================= #

        loss_falsePositives = torch.nn.functional.mse_loss(
            input=preds_exists_not_confidence,
            target=targets_exists_not_confidence,
            reduction="sum",
        )
        
        # ========================= #
        #   LOSS: BOX COORDINATES   #
        # ========================= #

        # First find which predicted bounding box (of the B predicted bounding boxes) has the highest IoU with the target bounding box.
        # iou is the Intersection over Union of the predicted bounding box with respect to the target bounding box.
        # It is a measure of the overlap between the predicted bounding box and the target bounding box.
        iou = intersection_over_union(predictions[..., 0:4], targets[..., 0:4])  ## shape: (N, S, S, B_pred, B_gt)

        ## Get the best iou scores for each predicted bounding box for each grid cell.
        ## Take the max over the B_pred dimension to get the best iou score for each ground truth bounding box and the argmax of the best B_pred bounding box.
        iou_max, iou_argmax = iou.max(dim=-2)  ## shape: (N, S, S, B_gt)

        preds_exists_iouBest = torch.cat([predictions[((iou_argmax==b) * exists_box)[...,None].expand_as(predictions)].view(-1, 5 + self.C) for b in range(self.B)], dim=0)

        targets_exists_ioutBest = torch.cat([targets[((iou_argmax==b) * exists_box)[...,None].expand_as(targets)].view(-1, 5 + self.C) for b in range(self.B)], dim=0)

        loss_xy = torch.nn.functional.mse_loss(preds_exists_iouBest[:, :2], targets_exists_ioutBest[:, :2], reduction='sum')
        loss_wh = torch.nn.functional.mse_loss(torch.sqrt(preds_exists_iouBest[:, 2:4].clamp(0)), torch.sqrt(targets_exists_ioutBest[:, 2:4].clamp(0)), reduction='sum')

        # ======================== #
        #   LOSS: FALSE NEGATIVES  #
        # ======================== #

        loss_obj = torch.nn.functional.mse_loss(preds_exists_iouBest[:, 4], targets_exists_ioutBest[:, 4], reduction='sum')

        # ================== #
        #   FOR CLASS LOSS   #
        # ================== #
        
        # Calculate the class loss.
        # loss_class = torch.nn.functional.cross_entropy(
        #     input=preds_exists_class,
        #     target=targets_exists_class.argmax(dim=-1),
        #     reduction="sum",
        # )
        loss_class = torch.nn.functional.mse_loss(
            input=preds_exists_class,
            target=targets_exists_class,
            reduction="sum",
        )

        # ================== #
        #   FOR TOTAL LOSS   #
        # ================== #
        
        loss_dict = {
            "loss_xy": loss_xy * self.lambda_xy,
            "loss_wh": loss_wh * self.lambda_wh,
            "loss_obj": loss_obj * self.lambda_obj,
            "loss_falsePositives": loss_falsePositives * self.lambda_fp,
            "loss_class": loss_class * self.lambda_class,
        }

        loss_total = sum(loss for loss in loss_dict.values()) / N
        
        return loss_total, loss_dict