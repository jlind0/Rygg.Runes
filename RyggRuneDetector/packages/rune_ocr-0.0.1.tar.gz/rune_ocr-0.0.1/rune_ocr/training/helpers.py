import torch
import torchvision
import numpy as np

def paste_image(im_back, im_overlay, x, y):
    """
    Paste one torch tensor image onto another, given x,y coordinates.
    Allow for the coordinates to exist outside of the bounds of the background image.

    Args:
        im_back (torch.Tensor): 
            Background image.
            *Shape: (batch_size, channels, height, width)*
        im_overlay (torch.Tensor):
            Overlay image.
            *Shape: (batch_size, channels, height, width)*
        x (int):
            x-coordinate of the center of the overlay image.
        y (int):
            y-coordinate of the center of the overlay image.
    """
#     assert x >= 0 and y >= 0, "Coordinates must be non-negative"
    assert im_back.shape[:2] == im_overlay.shape[:2], "Images must have the same batch size and channel number"

    # Calculate start and end indices for x and y
    h, w = im_overlay.shape[2:]
    start_x = max(x - w // 2, 0)
    end_x = min(x + w // 2, im_back.shape[3])
    start_y = max(y - h // 2, 0)
    end_y = min(y + h // 2, im_back.shape[2])

    # Check if overlay is out of bounds
    if start_x >= im_back.shape[3] or start_y >= im_back.shape[2] or end_x <= 0 or end_y <= 0:
        return im_back  # Return original image if overlay is out of bounds

    # Adjust overlay if it's partially out of bounds
    overlay_start_x = max(0, w // 2 - x)
    overlay_end_x = overlay_start_x + end_x - start_x
    overlay_start_y = max(0, h // 2 - y)
    overlay_end_y = overlay_start_y + end_y - start_y

    # Paste overlay onto background
    im_back[..., start_y:end_y, start_x:end_x] = im_back[..., start_y:end_y, start_x:end_x] + im_overlay[..., overlay_start_y:overlay_end_y, overlay_start_x:overlay_end_x]
    
    return im_back


def at_least_ND(tensor, N, position='front'):
    """
    Pads singleton dimensions to the front or back of a tensor until it is at
    least N-dimensional.
    RH 2023

    Args:
        tensor (torch.Tensor):
            Tensor to pad.
        N (int):
            Minimum number of dimensions.
        position (str):
            Where to pad the tensor. Can be 'front' or 'back'.
    """
    while tensor.ndim < N:
        if position == 'front':
            tensor = tensor.unsqueeze(0)
        elif position == 'back':
            tensor = tensor.unsqueeze(-1)
        else:
            raise ValueError("position must be 'front' or 'back'")

    return tensor


class ImageComposer:
    def __init__(
        self, 
        datasets_background, 
        dataset_overlay, 
        n_overlay_max=9,
        n_classes_overlay=24,
        size_overlay=(0.05, 1.0),
    ):
        # Store the background and overlay datasets
        self.dataset_background = torch.utils.data.ConcatDataset(datasets_background)
        self.dataset_overlay = dataset_overlay

        # Store the maximum number of overlays allowed
        self.n_overlay_max = n_overlay_max

        # Store the range of sizes for the overlay
        self.size_overlay = size_overlay
        
        self.rand_between = lambda low, high : (high - low) * torch.rand(1) + low
        
        self.n_classes_overlay = n_classes_overlay
        
    def compose(self, idx=None):
        idx = torch.randint(low=0, high=len(self.dataset_background), size=(1,)) if idx is None else idx

        # Select a background image from the chosen dataset and convert it to a tensor
        im_background = self.dataset_background[idx][0]

        # Ensure the background image tensor is at least 4D
        im_background = at_least_ND(
            im_background,
            N=4,
            position='front',
        ).type(torch.float32)

        # Randomly determine the number of overlays to apply
        n_overlay = int(torch.randint(low=0, high=self.n_overlay_max, size=(1,)))

        x,y = [], []
        size_x, size_y = [], []
        class_overlay = []
        im_composed = im_background
        for i_overlay in range(n_overlay):
            # Randomly select an overlay image, convert it to a tensor, and ensure it is at least 4D
            overlay = self.dataset_overlay[torch.randint(low=0, high=len(self.dataset_overlay), size=(1,))]
            im_overlay = at_least_ND(
                overlay[0],
                N=4,
                position='front',
            ).type(torch.float32)
            
            class_overlay.append(overlay[1])

            # Determine the size of the overlay based on the size of the background and the overlay size range
            len_min = int(min(list(im_background.shape[-2:])) * float(torch.exp(self.rand_between(low=torch.log(torch.as_tensor([self.size_overlay[0]])), high=torch.log(torch.as_tensor([self.size_overlay[1]]))))))
            im_overlay = torchvision.transforms.functional.resize(img=im_overlay, size=(len_min, len_min))

            # Paste the overlay onto the composed image at a random position
            x.append(int(torch.randint(low=0, high=im_background.shape[-1], size=(1,))))
            y.append(int(torch.randint(low=0, high=im_background.shape[-2], size=(1,))))
            
            size_x.append(im_overlay.shape[-1])
            size_y.append(im_overlay.shape[-2])
            
            im_composed = paste_image(
                im_back=im_composed,
                im_overlay=im_overlay,
                x=x[-1],
                y=y[-1],
            )

        # Convert the composed image to 8-bit and clip it to the range [0, 1]
        im_composed = at_least_ND(
                torch.as_tensor(torch.clip(im_composed*255, min=0, max=255), dtype=torch.uint8), 
                N=4, 
                position='front'
            )
        
        # Return the composed image
        x = torch.as_tensor(x)
        y = torch.as_tensor(y)
        size_x = torch.as_tensor(size_x)
        size_y = torch.as_tensor(size_y)
        return im_composed[0], (x,y), (size_x,size_y), class_overlay
    
    def __call__(self, idx=None):
        return self.compose(idx=idx)
    

class Dataset_ImageComposer(torch.utils.data.Dataset):
    def __init__(
        self,
        image_composer,
        S=7,
        B=2,
        C=25,
        im_shape=(224,224),
        transform=None,
    ):
        super().__init__()
        self.image_composer = image_composer

        self.S = S
        self.B = B
        self.C = C
        self.im_shape = im_shape

        self.transform = transform

    def __len__(self):
        return len(self.image_composer.dataset_background)
    
    def __getitem__(self, idx):
        im_composed, (x,y), (size_x,size_y), class_overlay = self.image_composer(idx=idx)

        encoding = encode_to_YOLO(
            coords_x_y=torch.stack((x,y), dim=-1), 
            boxes_w_h=torch.stack((size_x,size_y), dim=-1),
            classes=class_overlay,
            S=self.S,
            B=self.B,
            C=self.C,
            im_shape=self.im_shape,
        )

        if self.transform is not None:
            im_composed = self.transform(im_composed)

        return im_composed, encoding

def encode_to_YOLO(
    coords_x_y,
    boxes_w_h,
    classes,
    S=7,
    B=2,
    C=25,
    im_shape=(224,224),
):
    """
    Function to encode bounding box coordinates, dimensions, and class information into the YOLO encoding format.

    Args:
        coords_x_y (tensor): Tensor of shape (n_objs,2) containing x, y coordinates of bounding boxes.
        boxes_w_h (tensor): Tensor of shape (n_objs,2) containing width and height of bounding boxes.
        classes (tensor): Tensor of shape (n_objs,) containing class labels for each bounding box.
        S (int): The number of grid cells along each dimension.
        B (int): The number of bounding boxes per grid cell.
        C (int): The number of classes.
        im_shape (tuple): A tuple representing the dimensions of the image.

    Returns:
        encoding (tensor): Tensor of shape (1, S, S, B, 5+C) representing the YOLO encoding of the bounding boxes.
                            The last dimension represents: [x, y, w, h, confidence, class1, class2, ..., classC]
    """
    
    coords_x_y = torch.as_tensor(coords_x_y, dtype=torch.float32)
    boxes_w_h  = torch.as_tensor(boxes_w_h,  dtype=torch.float32)
    classes    = torch.as_tensor(classes, dtype=torch.int64)

    len_cell = torch.as_tensor(im_shape) / S  # shape: (2,)  ## length of each grid cell
    encoding = torch.zeros((S, S, B, 5 + C), dtype=torch.float32)  # shape: (S,S,B,5+C)  ## encoding tensor

    cellCoords_x_y = coords_x_y / len_cell[None,:]  # shape: (n_objs,2)  ## coordinates of boxes scaled to grid cell size
    subCellCoords_x_y = torch.remainder(cellCoords_x_y, 1)  # shape: (n_objs,2)  ## coordinates within each cell
    roundedCellCoords_x_y = (cellCoords_x_y // 1).type(torch.int64)  # shape: (n_objs,2)  ## grid cell indices for each box

    # we order objects by size to ensure larger objects get priority in encoding
    order_priority = torch.argsort(boxes_w_h.sum(-1), descending=True).type(torch.int64)  # shape: (n_objs,)  ## order of priority for encoding boxes

    # we arrange our data in order of priority
    roundedCellCoords_x_y_ordered = roundedCellCoords_x_y[order_priority]  # shape: (n_objs,2)
    subCellCoords_x_y_ordered = subCellCoords_x_y[order_priority]  # shape: (n_objs,2)
    boxes_x_y_ordered = boxes_w_h[order_priority]  # shape: (n_objs,2)
    classes_ordered = classes[order_priority]  # shape: (n_objs,)

    # we keep track of how many boxes have been assigned to each cell
    occupied_grid = torch.zeros((S,S), dtype=torch.int64)  # shape: (S,S)

    # we iterate over each box and encode it into our encoding tensor
    n_objs = len(classes)
    for i_obj in range(n_objs):
        rcco_y_x = tuple(roundedCellCoords_x_y_ordered[i_obj])[::-1]  # shape: (2,)
        b = occupied_grid[rcco_y_x]  # shape: ()  ## current bounding box index for this cell
        if b < B:
            # we encode the box information into the encoding tensor
            e = torch.cat((
                subCellCoords_x_y_ordered[i_obj],   # shape: (2,)
                boxes_x_y_ordered[i_obj],   # shape: (2,)
                torch.as_tensor([1], dtype=torch.float32),   # shape: (1,)
                torch.nn.functional.one_hot(classes_ordered[i_obj], num_classes=C),  # shape: (C,)
            ), dim=0)
            encoding[rcco_y_x[0], rcco_y_x[1], b, :] = e  # shape: (5 + C)
            # we increment the count of boxes in this cell
            occupied_grid[rcco_y_x] += 1
        else:
            continue

    return encoding  # shape: (S,S,B,5+C)

def decode_from_YOLO(
    encoding,
    im_shape=(224,224),
):
    """
    Function to decode the YOLO encoding format into bounding box coordinates,
    dimensions, and class information.
    RH 2023

    Args:
        encoding (tensor): 
            Tensor of shape (N, S, S, B, 5+C) representing the YOLO encoding of
            the bounding boxes for N images.
        im_shape (tuple): 
            A tuple representing the dimensions of the image.

    Returns:
        x_y (tensor): 
            Tensor of shape (N, S*S*B, 2) containing x, y coordinates of
            bounding boxes for each image.
        size_x_size_y (tensor): 
            Tensor of shape (N, S*S*B, 2) containing width and height of
            bounding boxes for each image.
        class_overlay (tensor): 
            Tensor of shape (N, S*S*B) containing class labels for each bounding
            box.
        confidences (tensor): 
            Tensor of shape (N, S*S*B) containing confidence scores for each
            bounding box.
    """

    device = encoding.device
    N, S, _, B, _ = encoding.shape  # shape of encoding tensor
    C = encoding.shape[-1] - 5  # number of classes

    coordinates = encoding[..., 0:2]  # shape: (N,S,S,B,2)  ## box coordinates within each cell
    boxes = encoding[..., 2:4]  # shape: (N,S,S,B,2)  ## box dimensions
    confidences = encoding[..., 4]  # shape: (N,S,S,B)  ## confidence scores
    class_probs = encoding[..., 5:]  # shape: (N,S,S,B,C)  ## class probabilities

    cell_size = torch.tensor(im_shape, dtype=torch.int64, device=device) / S  # shape: (2,)  ## size of each cell
    cell_size_unsqueezed = cell_size[None,None,None,None,:]  # shape: (1,1,1,1,2)

    # we create a grid of indices for each cell
    grid_indices = torch.tile(
        torch.stack(
            torch.meshgrid(
                torch.arange(S), 
                torch.arange(S), 
                indexing='xy',
            ), 
            dim=-1
        )[None,:,:,None,:],
        (1,1,1,B,1),
    ).type(torch.int64).to(device) * cell_size_unsqueezed  # shape: (N,S,S,B,2)

    # Compute absolute x, y coordinates
    x_y = (coordinates * cell_size_unsqueezed + grid_indices).view(N, -1, 2)  # shape: (n_objs, S*S*B, 2)

    # Compute size_x, size_y
    size_x_size_y = (boxes).view(N, -1, 2)  # shape: (n_objs, S*S*B, 2)

    # Compute class_overlay
    class_overlay = torch.argmax(class_probs.view(N, -1, class_probs.size(-1)), dim=-1)  # shape: (n_objs, S*S*B)

    # Flatten confidences
    confidences = confidences.view(N, -1)  # shape: (n_objs, S*S*B)

    return x_y, size_x_size_y, class_overlay, confidences


def xywh_to_xxyy(xywh, mode='center', round=True):
    x,y,w,h = (torch.as_tensor(v) for v in xywh)
    
    if mode == 'center':
        x1 = x - w/2
        x2 = x + w/2
        y1 = y - h/2
        y2 = y + h/2
    elif mode == 'corner':
        x1 = x
        x2 = x + w
        y1 = y
        y2 = y + h
    else:
        raise ValueError("mode must be 'center' or 'corner'")
    
    if round:
        x1 = int(torch.round(x1))
        x2 = int(torch.round(x2))
        y1 = int(torch.round(y1))
        y2 = int(torch.round(y2))

    return torch.as_tensor([x1,x2,y1,y2])

def xxyy_to_xywh(xxyy, mode='center', round=True):
    x1,x2,y1,y2 = (torch.as_tensor(v) for v in xxyy)
    
    if mode == 'center':
        x = (x1 + x2)/2
        y = (y1 + y2)/2
        w = x2 - x1
        h = y2 - y1
    elif mode == 'corner':
        x = x1
        y = y1
        w = x2 - x1
        h = y2 - y1
    else:
        raise ValueError("mode must be 'center' or 'corner'")
    
    if round:
        x = int(torch.round(x))
        y = int(torch.round(y))
        w = int(torch.round(w))
        h = int(torch.round(h))

    return torch.as_tensor([x,y,w,h])
